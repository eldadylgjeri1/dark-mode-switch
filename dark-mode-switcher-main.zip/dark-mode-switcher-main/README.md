# dark-mode-switcher
Activating the switch mode using a single button and only the core programming languages: HTML,CSS and Javascript.
